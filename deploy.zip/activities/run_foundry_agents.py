"""
Activity: run_foundry_agents — call Foundry Orchestrator Agent (T-024, ADR-002)

Orchestrator Agent manages the Research → Document pipeline natively via
Connected Agents (AgentTool). This activity creates a thread, sends the full
incident context as a user message, and waits for the agent to produce a
structured JSON analysis.

Returns:
    {
        "title": str,
        "analysis": str,
        "root_cause": str,
        "operator_dialogue": str,    # concise human-facing summary for chat transcript
        "recommendations": list[dict],
        "regulatory_refs": list[str],
        "sop_refs": list[str],
        "confidence": float,          # 0.0–1.0
        "risk_level": str,
        "classification": str,
        "batch_disposition": str,
        "evidence_citations": list,
        "work_order_draft": dict,
        "audit_entry_draft": dict,
        "raw_response": str,          # always present for audit trail
    }
"""

import json
import logging
import os
import random
import re
import time
from collections.abc import Sequence
from datetime import datetime, timezone
from difflib import SequenceMatcher
from functools import lru_cache
from pathlib import Path
from urllib.parse import quote

import azure.durable_functions as df
from azure.ai.agents import AgentsClient
from azure.ai.agents.models import (
    AgentThreadCreationOptions,
    MessageRole,
    RunStatus,
    ThreadMessageOptions,
)
from azure.identity import DefaultAzureCredential

from shared.cosmos_client import get_container
from shared.foundry_run import (
    FoundryRunTimeoutError,
    create_thread_and_process_run_with_approval,
)
from shared.search_utils import search_all_indexes

logger = logging.getLogger(__name__)

CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", "0.75"))
SEARCH_ENABLED = bool(os.getenv("AZURE_SEARCH_ENDPOINT", ""))
try:
    FOUNDRY_ACTIVITY_TIMEOUT_SECS = max(
        240.0,
        float(os.getenv("FOUNDRY_ACTIVITY_TIMEOUT_SECS", "240")),
    )
except ValueError:
    FOUNDRY_ACTIVITY_TIMEOUT_SECS = 240.0

INDEX_EVIDENCE_META = {
    "idx-sop-documents": {"type": "sop", "container": "blob-sop"},
    "idx-equipment-manuals": {"type": "manual", "container": "blob-manuals"},
    "idx-bpr-documents": {"type": "bpr", "container": "blob-bpr"},
    "idx-gmp-policies": {"type": "gmp", "container": "blob-gmp"},
    "idx-incident-history": {"type": "historical", "container": "blob-history"},
}

TRACE_MARKER = "FOUNDRY_PROMPT_TRACE"
try:
    TRACE_CHUNK_SIZE = max(
        2000,
        int(os.getenv("FOUNDRY_PROMPT_TRACE_CHUNK_SIZE", "12000")),
    )
except ValueError:
    TRACE_CHUNK_SIZE = 12000

REPO_ROOT = Path(__file__).resolve().parents[2]
AGENT_PROMPTS_DIR = REPO_ROOT / "agents" / "prompts"

DEFAULT_AGENT_MODEL = "gpt-4o-mini"
DEFAULT_DOCUMENT_AGENT_MODEL = "gpt-4o"

bp = df.Blueprint()


@bp.activity_trigger(input_name="input_data")
def run_foundry_agents(input_data: dict) -> dict:
    incident_id: str = input_data["incident_id"]
    context_data: dict = input_data["context"]
    previous_ai_result: dict = input_data.get("previous_ai_result") or {}
    more_info_round: int = input_data.get("more_info_round", 0)

    logger.info(
        "run_foundry_agents: incident=%s round=%d", incident_id, more_info_round
    )

    # Write analysis_started event on the first (non-more_info) run
    if more_info_round == 0:
        _write_analysis_started_event(incident_id)

    orchestrator_agent_id = os.environ.get("ORCHESTRATOR_AGENT_ID", "") or "asst_CNYK3TZIaOCH4OPKcP4N9B2r"
    if not orchestrator_agent_id:
        raise EnvironmentError(
            "ORCHESTRATOR_AGENT_ID env var is not set. "
            "Run agents/create_agents.py first to provision Foundry agents."
        )

    # ── Pre-fetch RAG context from all 5 AI Search indexes ─────────────────
    rag_context: dict = {}
    if SEARCH_ENABLED:
        equipment_id = context_data.get("equipment_id") or (
            context_data.get("equipment", {}).get("id")
        )
        alert = context_data.get("alert_payload", {})
        search_query = (
            f"{alert.get('alert_type', '')} {alert.get('deviation_description', '')} "
            f"{alert.get('parameter', '')} {alert.get('equipment_id', '')}"
        ).strip() or f"GMP deviation incident {incident_id}"
        try:
            rag_context = search_all_indexes(
                query=search_query,
                equipment_id=equipment_id,
                top_k=3,
            )
            logger.info(
                "RAG pre-fetch: %d total chunks for incident %s",
                sum(len(v) for v in rag_context.values()),
                incident_id,
            )
        except Exception as exc:
            logger.warning("RAG pre-fetch failed (non-fatal): %s", exc)

    # Startup stagger: deterministically spread concurrent incidents to avoid
    # thundering-herd on the Foundry rate limit.  Uses the numeric suffix of the
    # incident ID to derive a 0-60 s offset (e.g. INC-2026-0048 → 48*17 % 60 = 36 s).
    try:
        suffix = int(incident_id.rsplit("-", 1)[-1])
        stagger = (suffix * 17) % 60
    except ValueError:
        stagger = random.randint(0, 59)
    if stagger > 0:
        logger.info(
            "Startup stagger %.0fs for %s (thundering-herd prevention)",
            stagger, incident_id,
        )
        time.sleep(stagger)

    prompt = _build_prompt(
        incident_id,
        context_data,
        more_info_round,
        rag_context,
        previous_ai_result,
    )
    _log_orchestrator_prompt_trace(
        incident_id=incident_id,
        more_info_round=more_info_round,
        orchestrator_agent_id=orchestrator_agent_id,
        prompt=prompt,
        context_data=context_data,
    )
    try:
        result = _call_orchestrator_agent(
            prompt,
            orchestrator_agent_id,
            incident_id=incident_id,
            more_info_round=more_info_round,
        )
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Foundry analysis failed for incident %s round=%d: %s",
            incident_id,
            more_info_round,
            exc,
            exc_info=True,
        )
        result = _build_agent_failure_result(
            incident_id=incident_id,
            previous_ai_result=previous_ai_result,
            more_info_round=more_info_round,
            error=exc,
        )

    result = _normalize_agent_result(
        result,
        rag_context,
        more_info_round,
        previous_ai_result=previous_ai_result,
        operator_questions=context_data.get("operator_questions", []),
    )

    # Confidence gate (RAI Gap #4): log warning but still return result
    confidence = result.get("confidence", 0.0)
    if confidence < CONFIDENCE_THRESHOLD:
        logger.warning(
            "Low confidence %.2f for incident %s (threshold=%.2f). "
            "Consider requesting more_info.",
            confidence,
            incident_id,
            CONFIDENCE_THRESHOLD,
        )
        result["confidence_flag"] = "LOW_CONFIDENCE"

    _log_trace_json(
        incident_id=incident_id,
        more_info_round=more_info_round,
        trace_kind="normalized_result",
        payload=result,
    )

    return result


# ── Internal helpers ──────────────────────────────────────────────────────


_RATE_LIMIT_MAX_RETRIES = 5
# Base backoff in seconds; actual wait = base + random jitter (0..base/2)
# This prevents thundering herd when multiple incidents retry simultaneously.
_RATE_LIMIT_BACKOFF_SECS = [30, 60, 90, 120, 180]


def _is_rate_limit_error(err: object) -> bool:
    """Return True if the error is a transient rate-limit / throttle error.

    Handles both plain exceptions/strings and Azure SDK RunError objects
    that expose ``.code`` / ``.message`` attributes.
    """
    # Collect all text representations
    parts = [str(err)]
    if hasattr(err, "code"):
        parts.append(str(getattr(err, "code", "") or ""))
    if hasattr(err, "message"):
        parts.append(str(getattr(err, "message", "") or ""))
    combined = " ".join(parts).lower()
    return (
        "rate_limit" in combined
        or "rate limit" in combined
        or "429" in combined
        or "throttl" in combined
    )


def _call_orchestrator_agent(
    prompt: str,
    agent_id: str,
    *,
    incident_id: str,
    more_info_round: int,
) -> dict:
    """Create a Foundry thread, run the Orchestrator Agent, return parsed result.

    Uses ``create_thread_and_process_run_with_approval`` to handle MCP tool
    approval automatically — the Foundry API (2025-05-15-preview) does not
    persist ``require_approval="never"`` for MCP tools, so every MCP call
    triggers a ``submit_tool_approval`` action that must be approved client-side.

    Rate-limit errors are retried up to _RATE_LIMIT_MAX_RETRIES times with
    exponential back-off.
    """
    deadline = time.monotonic() + FOUNDRY_ACTIVITY_TIMEOUT_SECS

    last_exc: Exception | None = None
    for attempt in range(_RATE_LIMIT_MAX_RETRIES + 1):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise FoundryRunTimeoutError(
                f"Foundry activity budget exhausted after {FOUNDRY_ACTIVITY_TIMEOUT_SECS:.0f}s"
            )

        if attempt > 0:
            base = _RATE_LIMIT_BACKOFF_SECS[min(attempt - 1, len(_RATE_LIMIT_BACKOFF_SECS) - 1)]
            wait = base + random.uniform(0, base / 2)
            wait = min(wait, max(0.0, remaining - 5.0))
            if wait <= 0:
                raise FoundryRunTimeoutError(
                    f"Foundry activity budget exhausted during retry backoff after {FOUNDRY_ACTIVITY_TIMEOUT_SECS:.0f}s"
                )
            logger.warning(
                "Rate limit hit for incident agent (attempt %d/%d) — waiting %.0fs (remaining budget %.0fs)",
                attempt, _RATE_LIMIT_MAX_RETRIES, wait,
                max(0.0, deadline - time.monotonic()),
            )
            time.sleep(wait)

        try:
            client = _build_agents_client()
            with client:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise FoundryRunTimeoutError(
                        f"Foundry activity budget exhausted before run start after {FOUNDRY_ACTIVITY_TIMEOUT_SECS:.0f}s"
                    )

                run = create_thread_and_process_run_with_approval(
                    client,
                    agent_id=agent_id,
                    thread=AgentThreadCreationOptions(
                        messages=[
                            ThreadMessageOptions(role=MessageRole.USER, content=prompt)
                        ]
                    ),
                    max_wait_seconds=remaining,
                )

                if run.status in (RunStatus.FAILED, "failed") or str(run.status).lower() == "failed":
                    err = getattr(run, "last_error", run.status)
                    logger.warning(
                        "Foundry run failed (attempt %d/%d): code=%s message=%s",
                        attempt + 1, _RATE_LIMIT_MAX_RETRIES + 1,
                        getattr(err, "code", ""),
                        getattr(err, "message", str(err))[:200],
                    )
                    if _is_rate_limit_error(err):
                        last_exc = RuntimeError(f"Foundry Orchestrator run failed: {err}")
                        continue  # retry
                    raise RuntimeError(f"Foundry Orchestrator run failed: {err}")

                logger.info(
                    "Foundry run completed: status=%s thread=%s run=%s",
                    run.status, run.thread_id, run.id,
                )

                message_items = list(client.messages.list(thread_id=run.thread_id))
                _log_trace_json(
                    incident_id=incident_id,
                    more_info_round=more_info_round,
                    trace_kind="thread_messages",
                    payload={
                        "thread_id": run.thread_id,
                        "run_id": run.id,
                        "status": str(run.status),
                        "messages": _serialize_thread_messages(message_items),
                    },
                )

                # list_messages returns newest-first; first AGENT message is the answer.
                # NOTE: azure-ai-agents SDK uses MessageRole.AGENT (value="assistant"),
                # but str(MessageRole.AGENT) == "MessageRole.AGENT", NOT "assistant".
                raw_text = ""
                for msg in message_items:
                    role = getattr(msg, "role", None)
                    is_agent = (
                        role == MessageRole.AGENT
                        if hasattr(MessageRole, "AGENT")
                        else "assistant" in str(getattr(role, "value", role)).lower()
                    )
                    if is_agent:
                        for block in msg.content:
                            text_block = getattr(block, "text", None)
                            text_value = getattr(text_block, "value", None)
                            if text_value:
                                raw_text += str(text_value)
                        break

                logger.info(
                    "Foundry raw response length=%d first 500 chars: %s",
                    len(raw_text), raw_text[:500],
                )
                _log_trace_text(
                    incident_id=incident_id,
                    more_info_round=more_info_round,
                    trace_kind="raw_response",
                    text=raw_text,
                    metadata={
                        "thread_id": run.thread_id,
                        "run_id": run.id,
                        "agent_id": agent_id,
                    },
                )
                parsed = _parse_response(raw_text)
                _log_trace_json(
                    incident_id=incident_id,
                    more_info_round=more_info_round,
                    trace_kind="parsed_response",
                    payload=parsed,
                    metadata={
                        "thread_id": run.thread_id,
                        "run_id": run.id,
                        "agent_id": agent_id,
                    },
                )
                return parsed

        except Exception as exc:  # noqa: BLE001
            if _is_rate_limit_error(exc):
                last_exc = exc
                continue  # retry on rate limit
            raise  # re-raise non-rate-limit errors immediately

    # All retries exhausted
    raise last_exc or RuntimeError("run_foundry_agents: all retries exhausted")


def _build_agent_failure_result(
    *,
    incident_id: str,
    previous_ai_result: dict,
    more_info_round: int,
    error: Exception,
) -> dict:
    previous = dict(previous_ai_result or {})
    error_text = str(error).strip() or error.__class__.__name__
    is_timeout = isinstance(error, FoundryRunTimeoutError)
    failure_flag = "FOUNDRY_TIMEOUT" if is_timeout else "FOUNDRY_FAILURE"

    if previous and more_info_round > 0:
        recommendation = str(previous.get("recommendation") or "").strip()
        analysis_note = (
            "The latest AI follow-up did not complete successfully, so the previous completed recommendation remains the current guidance. "
            f"Reason: {error_text[:300]}"
        )
        previous_analysis = str(previous.get("analysis") or "").strip()
        merged_analysis = (
            f"{analysis_note}\n\nPrevious completed analysis:\n{previous_analysis}"
            if previous_analysis
            else analysis_note
        )
        return {
            **previous,
            "incident_id": incident_id,
            "analysis": merged_analysis[:4000],
            "operator_dialogue": (
                "I could not finish the follow-up review in time. "
                "The previous completed recommendation is still the latest guidance; "
                "please review it manually or retry the follow-up question later."
            )[:800],
            "confidence_flag": failure_flag,
            "manual_review_required": True,
            "raw_response": error_text,
        }

    return {
        "incident_id": incident_id,
        "title": "Manual Review Required",
        "classification": "analysis_unavailable",
        "risk_level": "LOW_CONFIDENCE",
        "confidence": 0.0,
        "root_cause": "The AI agent did not complete the analysis successfully.",
        "analysis": (
            "The AI analysis did not complete within the allowed execution budget. "
            "The workflow returned a controlled fallback so the incident does not remain stuck in awaiting_agents. "
            f"Reason: {error_text[:300]}"
        ),
        "recommendation": (
            "Manual review is required before proceeding. Retry the AI analysis later if additional automated guidance is still needed."
        ),
        "operator_dialogue": (
            "I could not complete the AI analysis in time. "
            "Manual review is required before proceeding, but the incident is no longer stuck waiting for the agent."
        )[:800],
        "capa_suggestion": "Manual QA review required before CAPA execution.",
        "recommendations": [],
        "regulatory_reference": "",
        "regulatory_refs": [],
        "sop_refs": [],
        "evidence_citations": [],
        "work_order_draft": {},
        "audit_entry_draft": {},
        "batch_disposition": "under_review",
        "confidence_flag": failure_flag,
        "manual_review_required": True,
        "raw_response": error_text,
    }


def _build_prompt(
    incident_id: str,
    context_data: dict,
    more_info_round: int,
    rag_context: dict | None = None,
    previous_ai_result: dict | None = None,
) -> str:
    """Build the user message that drives the Orchestrator Agent."""
    equipment = context_data.get("equipment", {})
    batch = context_data.get("batch", {})
    recent_incidents = context_data.get("recent_incidents", [])
    alert_payload = context_data.get("alert_payload", {})
    operator_questions = context_data.get("operator_questions", [])

    lines = [
        f"## GMP Deviation Analysis Request — Incident {incident_id}",
        f"**Timestamp:** {datetime.now(timezone.utc).isoformat()}",
        "",
        "### Alert Payload",
        "```json",
        json.dumps(alert_payload, indent=2, default=str),
        "```",
        "",
        "### Equipment Context",
        "```json",
        json.dumps(equipment, indent=2, default=str),
        "```",
        "",
        "### Active Batch",
        "```json",
        json.dumps(batch, indent=2, default=str),
        "```",
        "",
        f"### Recent Incidents (last {len(recent_incidents)} on this equipment)",
        "```json",
        json.dumps(recent_incidents, indent=2, default=str),
        "```",
    ]

    # ── RAG pre-fetched context (from all 5 AI Search indexes) ────────────
    if rag_context:
        _INDEX_LABELS = {
            "idx-sop-documents": "Relevant SOP Sections",
            "idx-equipment-manuals": "Equipment Manual Sections",
            "idx-bpr-documents": "BPR / Product Process Specs (NOR/PAR)",
            "idx-gmp-policies": "Applicable GMP Regulations & Policies",
            "idx-incident-history": "Similar Historical Incidents",
        }
        lines.append("")
        lines.append("### Pre-fetched RAG Context (AI Search — all 5 indexes)")
        lines.append(
            "> Use these excerpts as primary evidence. Cite document_title and section in your analysis."
        )
        for idx_name, hits in rag_context.items():
            if not hits:
                continue
            label = _INDEX_LABELS.get(idx_name, idx_name)
            lines.append(f"\n#### {label}")
            for hit in hits:
                lines.append(
                    f"**[{hit['document_title']}]** "
                    f"(index={idx_name}; source_blob={hit.get('source', '')}; "
                    f"chunk={hit.get('chunk_index', '')}; score={hit['score']:.3f}):\n"
                    f"{hit['text'][:600]}"
                )

    if operator_questions:
        lines += [
            "",
            f"### Operator Follow-up Questions (round {more_info_round})",
        ]
        for q in operator_questions:
            lines.append(
                f"- **Round {q['round']}** ({q.get('asked_by', 'operator')}): {q['question']}"
            )

    if more_info_round > 0 and previous_ai_result:
        lines += [
            "",
            "### Previous Recommendation Snapshot (for round comparison)",
            "Use this snapshot to explain what changed or stayed the same in this follow-up response.",
            "```json",
            json.dumps(
                {
                    "recommendation": previous_ai_result.get("recommendation", ""),
                    "root_cause": previous_ai_result.get("root_cause", ""),
                    "risk_level": previous_ai_result.get("risk_level", ""),
                    "batch_disposition": previous_ai_result.get("batch_disposition", ""),
                },
                indent=2,
                default=str,
            ),
            "```",
        ]

    lines += [
        "",
        "---",
        "### Instructions",
        (
            "The Pre-fetched RAG Context above contains relevant excerpts from SOPs, "
            "equipment manuals, BPR product specs, GMP regulations, and similar historical incidents "
            "retrieved via semantic search. Use these as your primary evidence base — cite them explicitly. "
            "Use your Research sub-agent to retrieve any additional context not covered above. "
            "Then use your Document sub-agent to produce the final structured analysis."
        ),
        "",
        "Return your response as a **single JSON block** using this exact schema:",
        "```json",
        json.dumps(
            {
                "incident_id": incident_id,
                "title": "Short operator-facing incident title in under 8 words",
                "classification": "process_parameter_excursion | equipment_malfunction | ...",
                "risk_level": "low | medium | high | critical",
                "confidence": 0.85,
                "confidence_flag": None,
                "root_cause": "Primary root cause in one sentence",
                "analysis": "Detailed root cause analysis with evidence.",
                "recommendation": "Recommended immediate action.",
                "operator_dialogue": (
                    "Round 0: concise summary for operator. "
                    "Round >0: start by saying what follow-up question you reviewed, "
                    "then state clearly whether recommendation/root cause changed or stayed the same, and why. "
                    "If the follow-up asks whether a BPR, SOP, or other document directly requires an action, "
                    "answer that explicitly in plain language instead of implying it. "
                    "Do not simply repeat the recommendation text."
                ),
                "capa_suggestion": "1. ...\n2. ...",
                "regulatory_reference": "SOP-DEV-001 §4.2; GMP Annex 15 §6.3",
                "batch_disposition": "conditional_release_pending_testing | rejected | release",
                "recommendations": [
                    {
                        "action": "...",
                        "priority": "critical|high|medium|low",
                        "owner": "...",
                        "deadline_days": 0,
                    }
                ],
                "regulatory_refs": [
                    {
                        "regulation": "EU GMP Annex 15",
                        "section": "§6.3",
                        "text_excerpt": "...",
                    }
                ],
                "sop_refs": [
                    {
                        "id": "SOP-DEV-001",
                        "title": "Deviation Management",
                        "relevant_section": "§4.2",
                        "text_excerpt": "...",
                    }
                ],
                "evidence_citations": [
                    {
                        "source": "SOP-DEV-001",
                        "section": "§4.2",
                        "text_excerpt": "...",
                    }
                ],
                "work_order_draft": {
                    "title": "...",
                    "description": "...",
                    "priority": "high",
                    "estimated_hours": 4,
                },
                "audit_entry_draft": {
                    "deviation_type": "...",
                    "description": "...",
                    "root_cause": "...",
                    "capa_actions": "...",
                },
                "tool_calls_log": [
                    {
                        "tool": "get_equipment",
                        "args": {"equipment_id": "GR-204"},
                        "status": "ok",
                    }
                ],
                "work_order_id": None,
                "audit_entry_id": None,
                "execution_error": None,
            },
            indent=2,
        ),
        "```",
        "",
        "Every field above is required except execution_error, which may be null when tool execution succeeds.",
        "Carry forward tool_calls_log from the Research Agent and preserve work_order_id/audit_entry_id from the Document Agent tool execution.",
        "Never fabricate data. Cite all sources. If confidence is below 0.75, "
        "set risk_level to 'LOW_CONFIDENCE' and explain what additional information "
        "would raise confidence.",
        "Always include operator_dialogue: plain language, under 120 words. "
        "For follow-up rounds, explicitly say what question you checked, what changed or why no change was needed. "
        "If the question asks whether a BPR, SOP, or other document directly requires an action, answer that explicitly with the evidence you found. "
        "and never just repeat the recommendation or analysis verbatim.",
    ]

    return "\n".join(lines)


def _log_orchestrator_prompt_trace(
    *,
    incident_id: str,
    more_info_round: int,
    orchestrator_agent_id: str,
    prompt: str,
    context_data: dict,
) -> None:
    if not _trace_enabled():
        return

    prompt_bundle = {
        "orchestrator_agent_id": orchestrator_agent_id,
        "configured_models": _configured_agent_models(),
        "operator_questions": context_data.get("operator_questions", []),
        "system_prompts": _system_prompt_snapshot(orchestrator_agent_id),
    }
    _log_trace_json(
        incident_id=incident_id,
        more_info_round=more_info_round,
        trace_kind="prompt_context",
        payload=prompt_bundle,
    )
    _log_trace_text(
        incident_id=incident_id,
        more_info_round=more_info_round,
        trace_kind="orchestrator_user_prompt",
        text=prompt,
        metadata={"orchestrator_agent_id": orchestrator_agent_id},
    )


def _configured_agent_models() -> dict[str, str]:
    return {
        "research": _resolve_agent_model("FOUNDRY_RESEARCH_AGENT_MODEL", DEFAULT_AGENT_MODEL),
        "document": _resolve_agent_model(
            "FOUNDRY_DOCUMENT_AGENT_MODEL",
            DEFAULT_DOCUMENT_AGENT_MODEL,
        ),
        "orchestrator": _resolve_agent_model(
            "FOUNDRY_ORCHESTRATOR_AGENT_MODEL",
            DEFAULT_AGENT_MODEL,
        ),
    }


def _resolve_agent_model(env_var: str, default_model: str) -> str:
    override = os.getenv(env_var, "").strip()
    if override:
        return override

    global_override = os.getenv("FOUNDRY_AGENT_MODEL", "").strip()
    if global_override:
        return global_override

    return default_model


def _build_agents_client() -> AgentsClient:
    endpoint = os.environ.get(
        "AZURE_AI_FOUNDRY_AGENTS_ENDPOINT",
        os.environ.get("AZURE_AI_FOUNDRY_PROJECT_CONNECTION_STRING", ""),
    )
    os.environ.setdefault("AZURE_AI_AGENTS_TESTS_IS_TEST_RUN", "True")
    return AgentsClient(endpoint=endpoint, credential=DefaultAzureCredential())


def _system_prompt_snapshot(orchestrator_agent_id: str) -> dict[str, str]:
    return {
        "orchestrator": _read_agent_prompt(orchestrator_agent_id, "orchestrator_system.md"),
        "research": _read_agent_prompt(
            os.getenv("RESEARCH_AGENT_ID", "").strip(),
            "research_system.md",
        ),
        "document": _read_agent_prompt(
            os.getenv("DOCUMENT_AGENT_ID", "").strip(),
            "document_system.md",
        ),
    }


def _read_agent_prompt(agent_id: str, file_name: str) -> str:
    live_instructions = _get_live_agent_instructions(agent_id)
    if live_instructions:
        return live_instructions

    prompt_path = _resolve_prompt_path(file_name)
    if prompt_path is None:
        return f"<prompt file unavailable: {file_name}>"

    try:
        return prompt_path.read_text(encoding="utf-8")
    except OSError as exc:
        return f"<failed to read {prompt_path}: {exc}>"


@lru_cache(maxsize=8)
def _get_live_agent_instructions(agent_id: str) -> str:
    if not agent_id:
        return ""

    try:
        client = _build_agents_client()
        with client:
            agent = client.get_agent(agent_id)
        return str(getattr(agent, "instructions", "") or "").strip()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to fetch live agent instructions for %s: %s", agent_id, exc)
        return ""


def _resolve_prompt_path(file_name: str) -> Path | None:
    direct_candidate = AGENT_PROMPTS_DIR / file_name
    if direct_candidate.is_file():
        return direct_candidate

    for parent in Path(__file__).resolve().parents:
        candidate = parent / "agents" / "prompts" / file_name
        if candidate.is_file():
            return candidate

    return None


def _serialize_thread_messages(messages: Sequence[object]) -> list[dict[str, object]]:
    serialized: list[dict[str, object]] = []
    for message in messages:
        serialized.append(
            {
                "id": getattr(message, "id", None),
                "role": _serialize_value(getattr(message, "role", None)),
                "created_at": getattr(message, "created_at", None),
                "metadata": _serialize_value(getattr(message, "metadata", None)),
                "content": _serialize_message_content(getattr(message, "content", [])),
            }
        )
    return serialized


def _serialize_message_content(content_blocks: Sequence[object] | None) -> list[dict[str, object]]:
    serialized_blocks: list[dict[str, object]] = []
    for block in content_blocks or []:
        text_block = getattr(block, "text", None)
        text_value = getattr(text_block, "value", None)
        serialized_blocks.append(
            {
                "type": getattr(block, "type", block.__class__.__name__),
                "text": text_value,
                "raw": _serialize_value(block if text_value is None else None),
            }
        )
    return serialized_blocks


def _serialize_value(value: object) -> object:
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _serialize_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_serialize_value(item) for item in value]
    if hasattr(value, "__dict__"):
        return {
            str(key): _serialize_value(item)
            for key, item in vars(value).items()
            if not key.startswith("_")
        }
    return str(value)


def _log_trace_json(
    *,
    incident_id: str,
    more_info_round: int,
    trace_kind: str,
    payload: object,
    metadata: dict[str, object] | None = None,
) -> None:
    _log_trace_text(
        incident_id=incident_id,
        more_info_round=more_info_round,
        trace_kind=trace_kind,
        text=json.dumps(payload, ensure_ascii=False, default=str, indent=2),
        metadata=metadata,
        content_type="json",
    )


def _log_trace_text(
    *,
    incident_id: str,
    more_info_round: int,
    trace_kind: str,
    text: str,
    metadata: dict[str, object] | None = None,
    content_type: str = "text",
) -> None:
    if not _trace_enabled():
        return

    metadata = metadata or {}
    chunks = _chunk_text(text or "", TRACE_CHUNK_SIZE)
    total_chunks = len(chunks)
    for index, chunk in enumerate(chunks, start=1):
        payload = {
            "marker": TRACE_MARKER,
            "incident_id": incident_id,
            "round": more_info_round,
            "trace_kind": trace_kind,
            "content_type": content_type,
            "chunk_index": index,
            "chunk_count": total_chunks,
            "metadata": metadata,
            "content": chunk,
        }
        logger.info("%s %s", TRACE_MARKER, json.dumps(payload, ensure_ascii=False, default=str))


def _chunk_text(text: str, size: int) -> list[str]:
    if not text:
        return [""]
    return [text[index:index + size] for index in range(0, len(text), size)]


def _trace_enabled() -> bool:
    return os.getenv("FOUNDRY_PROMPT_TRACE_ENABLED", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _parse_response(raw_text: str) -> dict:
    """Extract JSON block from agent response, with graceful fallback."""
    # Try ```json ... ``` block first
    match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw_text, re.DOTALL)
    if match:
        try:
            data = json.loads(match.group(1))
            data.setdefault("raw_response", raw_text)
            return data
        except json.JSONDecodeError:
            pass

    # Try to parse the whole response as JSON
    try:
        data = json.loads(raw_text.strip())
        data.setdefault("raw_response", raw_text)
        return data
    except json.JSONDecodeError:
        pass

    # Fallback — unstructured response (shouldn't happen in production)
    logger.warning("Could not parse structured JSON from Foundry agent response")
    return {
        "title": "Deviation Review Required",
        "analysis": raw_text[:2000] if raw_text else "Analysis not available.",
        "root_cause": "Could not determine root cause automatically.",
        "operator_dialogue": "I could not produce a structured follow-up summary for the operator.",
        "classification": "unknown",
        "risk_level": "unknown",
        "confidence": 0.5,
        "confidence_flag": "PARSE_ERROR",
        "recommendations": [],
        "regulatory_refs": [],
        "sop_refs": [],
        "evidence_citations": [],
        "work_order_draft": {},
        "audit_entry_draft": {},
        "batch_disposition": "hold_pending_review",
        "raw_response": raw_text,
    }


def _normalize_agent_result(
    result: dict,
    rag_context: dict | None,
    more_info_round: int,
    previous_ai_result: dict | None = None,
    operator_questions: list[dict] | None = None,
) -> dict:
    """Make citation output stable for the operator UI."""
    result["title"] = _normalize_incident_title(result)
    result["evidence_citations"] = _normalize_evidence_citations(result, rag_context or {})
    result["operator_dialogue"] = _normalize_operator_dialogue(
        result,
        more_info_round,
        previous_ai_result=previous_ai_result or {},
        operator_questions=operator_questions or [],
    )
    return result


def _normalize_operator_dialogue(
    result: dict,
    more_info_round: int,
    previous_ai_result: dict | None = None,
    operator_questions: list[dict] | None = None,
) -> str:
    explicit = str(result.get("operator_dialogue") or "").strip()
    previous_ai_result = previous_ai_result or {}
    operator_questions = operator_questions or []

    if more_info_round <= 0 and _should_rewrite_initial_operator_dialogue(explicit):
        explicit = ""

    if explicit and not _should_rewrite_followup_dialogue(
        explicit,
        result,
        previous_ai_result,
        operator_questions,
        more_info_round,
    ):
        return explicit[:800]

    recommendation = str(result.get("recommendation") or "").strip()
    analysis = str(result.get("analysis") or "").strip()

    if more_info_round <= 0:
        return (recommendation or analysis or "AI agent provided an initial recommendation.")[:800]

    if recommendation:
        return _build_followup_operator_dialogue(
            result,
            previous_ai_result,
            operator_questions,
        )[:800]

    return (
        "I reviewed your follow-up question and updated the analysis using available data."
    )[:800]


def _should_rewrite_initial_operator_dialogue(explicit: str) -> bool:
    normalized_explicit = _normalize_text(explicit)
    if not normalized_explicit:
        return False

    invalid_initial_markers = (
        "recommendation remains",
        "remains the same",
        "remains unchanged",
        "stayed the same",
        "recommendation stayed",
        "updated recommendation",
        "updated root cause",
        "follow-up question",
    )
    return any(marker in normalized_explicit for marker in invalid_initial_markers)


def _should_rewrite_followup_dialogue(
    explicit: str,
    result: dict,
    previous_ai_result: dict,
    operator_questions: list[dict],
    more_info_round: int,
) -> bool:
    if more_info_round <= 0:
        return not explicit

    normalized_explicit = _normalize_text(explicit)
    if not normalized_explicit:
        return True

    recommendation = _normalize_text(str(result.get("recommendation") or ""))
    previous_dialogue = _normalize_text(str(previous_ai_result.get("operator_dialogue") or ""))

    if len(normalized_explicit.split()) < 12:
        return True

    if recommendation and SequenceMatcher(None, normalized_explicit, recommendation).ratio() >= 0.88:
        return True

    if previous_dialogue and SequenceMatcher(None, normalized_explicit, previous_dialogue).ratio() >= 0.88:
        return True

    latest_question = _get_latest_operator_question(operator_questions)
    if latest_question and _is_direct_requirement_question(latest_question):
        if not _answers_direct_requirement_question(normalized_explicit):
            return True

    if latest_question and not _mentions_change_or_reason(normalized_explicit):
        return True

    return False


def _build_followup_operator_dialogue(
    result: dict,
    previous_ai_result: dict,
    operator_questions: list[dict],
) -> str:
    latest_question = _get_latest_operator_question(operator_questions)
    recommendation = str(result.get("recommendation") or "").strip()
    root_cause = str(result.get("root_cause") or "").strip()
    changed_fields = _get_changed_followup_fields(result, previous_ai_result)
    direct_requirement_answer = _build_direct_requirement_answer(latest_question, result)

    if latest_question:
        intro = f'I reviewed your follow-up question: "{_shorten_text(latest_question, 90)}".'
    else:
        intro = "I reviewed your follow-up question and re-checked the available evidence."

    if changed_fields:
        field_summary = _human_join(changed_fields)
        details: list[str] = [intro]
        if direct_requirement_answer:
            details.append(direct_requirement_answer)
        details.append(f"I updated {field_summary} based on the available evidence.")
        details.append(_build_updated_decision_summary(result))
        if root_cause and "the root cause hypothesis" in changed_fields:
            details.append(f"Updated root cause hypothesis: {_shorten_text(root_cause, 120)}")
        return _compose_dialogue_parts(details)

    no_change_parts = [intro]
    if direct_requirement_answer:
        no_change_parts.append(direct_requirement_answer)
        no_change_parts.append(_build_no_change_decision_reason(result))
    else:
        no_change_parts.append(
            "I did not find enough new evidence to change the current recommendation or root-cause hypothesis."
        )
    decision_summary = _build_current_decision_summary(result)
    if decision_summary:
        no_change_parts.append(decision_summary)
    return _compose_dialogue_parts(no_change_parts)


def _get_changed_followup_fields(result: dict, previous_ai_result: dict) -> list[str]:
    labels = {
        "recommendation": "the recommendation",
        "root_cause": "the root cause hypothesis",
        "risk_level": "the risk level",
        "batch_disposition": "the batch disposition",
    }
    changed: list[str] = []
    for field, label in labels.items():
        current_value = _normalize_text(str(result.get(field) or ""))
        previous_value = _normalize_text(str(previous_ai_result.get(field) or ""))
        if current_value and current_value != previous_value:
            changed.append(label)
    return changed


def _get_latest_operator_question(operator_questions: list[dict]) -> str:
    if not operator_questions:
        return ""
    latest = operator_questions[-1]
    return str(latest.get("question") or "").strip()


def _is_direct_requirement_question(question: str) -> bool:
    normalized_question = _normalize_text(question)
    if not normalized_question:
        return False

    requirement_markers = (
        "direct requirement",
        "directly require",
        "mandate",
        "requirement to",
        "required to",
        "must stop",
        "stop the line",
        "line stop",
    )
    document_markers = ("bpr", "sop", "document", "procedure")
    return any(marker in normalized_question for marker in requirement_markers) and any(
        marker in normalized_question for marker in document_markers
    )


def _answers_direct_requirement_question(normalized_dialogue: str) -> bool:
    answer_markers = (
        "i did not find a direct",
        "i found a direct",
        "there is no direct requirement",
        "there is a direct requirement",
        "the bpr does not",
        "the bpr requires",
        "the sop does not",
        "the sop requires",
        "does not directly require",
        "directly requires",
        "does not state",
        "states that",
    )
    return any(marker in normalized_dialogue for marker in answer_markers)


def _build_direct_requirement_answer(latest_question: str, result: dict) -> str:
    if not _is_direct_requirement_question(latest_question):
        return ""

    source, section, excerpt = _extract_requirement_evidence(result)
    if excerpt and _has_direct_stop_requirement(excerpt):
        source_label = _format_evidence_label(source, section)
        if source_label:
            return (
                f'I found a retrieved document instruction in {source_label} that directly requires a stop or hold action: '
                f'"{_shorten_text(excerpt, 140)}".'
            )
        return (
            f'I found a retrieved document instruction that directly requires a stop or hold action: '
            f'"{_shorten_text(excerpt, 140)}".'
        )

    if excerpt:
        source_label = _format_evidence_label(source, section)
        if source_label:
            return (
                "I did not find a retrieved BPR or SOP instruction that directly requires stopping the line at this condition. "
                f'The closest cited document limit in {source_label} is "{_shorten_text(excerpt, 140)}".'
            )
        return (
            "I did not find a retrieved BPR or SOP instruction that directly requires stopping the line at this condition. "
            f'The closest cited document limit is "{_shorten_text(excerpt, 140)}".'
        )

    return "I did not find a retrieved BPR or SOP instruction that directly requires stopping the line at this condition."


def _build_no_change_decision_reason(result: dict) -> str:
    source, section, excerpt = _extract_requirement_evidence(result)
    source_label = _format_evidence_label(source, section)
    batch_disposition = _humanize_batch_disposition(str(result.get("batch_disposition") or ""))

    if excerpt:
        if source_label and batch_disposition:
            return (
                f'I kept the recommendation and batch disposition unchanged because {source_label} still points to '
                f'"{_shorten_text(excerpt, 140)}", so the batch should remain {batch_disposition} while the deviation is investigated.'
            )
        if source_label:
            return (
                f'I kept the recommendation unchanged because {source_label} still points to '
                f'"{_shorten_text(excerpt, 140)}", and that does not support changing the current decision.'
            )

    if batch_disposition:
        return (
            f'I kept the recommendation and batch disposition unchanged because the available evidence still supports '
            f'keeping the batch {batch_disposition} while the deviation is investigated.'
        )

    return "I kept the recommendation unchanged because the available evidence still supports the current decision."


def _build_current_decision_summary(result: dict) -> str:
    summary_parts: list[str] = []

    batch_disposition = _humanize_batch_disposition(str(result.get("batch_disposition") or ""))
    if batch_disposition:
        summary_parts.append(f"The batch remains {batch_disposition}.")

    recommendation = str(result.get("recommendation") or "").strip()
    if recommendation:
        summary_parts.append(f"Recommended next action: {recommendation}")

    return " ".join(summary_parts).strip()


def _build_updated_decision_summary(result: dict) -> str:
    summary_parts: list[str] = []

    batch_disposition = _humanize_batch_disposition(str(result.get("batch_disposition") or ""))
    if batch_disposition:
        summary_parts.append(f"The batch is now {batch_disposition}.")

    recommendation = str(result.get("recommendation") or "").strip()
    if recommendation:
        summary_parts.append(f"Recommended next action: {_shorten_text(recommendation, 160)}")

    return " ".join(summary_parts).strip()


def _humanize_batch_disposition(batch_disposition: str) -> str:
    labels = {
        "hold_pending_review": "on hold pending review",
        "conditional_release_pending_testing": "under conditional release pending testing",
        "rejected": "rejected",
        "release": "released",
    }
    normalized = _normalize_text(batch_disposition)
    return labels.get(normalized, batch_disposition.replace("_", " ").strip())


def _extract_requirement_evidence(result: dict) -> tuple[str, str, str]:
    prioritized: list[tuple[str, str, str]] = []
    fallback: list[tuple[str, str, str]] = []

    for collection_name in ("evidence_citations", "sop_refs", "regulatory_refs"):
        for item in result.get(collection_name, []) or []:
            if not isinstance(item, dict):
                continue

            source = str(
                item.get("source")
                or item.get("document_title")
                or item.get("id")
                or item.get("regulation")
                or ""
            ).strip()
            section = str(item.get("section") or item.get("relevant_section") or "").strip()
            excerpt = str(item.get("text_excerpt") or "").strip()
            if not excerpt:
                continue

            normalized_haystack = _normalize_text(f"{source} {section} {excerpt}")
            candidate = (source, section, excerpt)
            if "bpr" in normalized_haystack or "product nor" in normalized_haystack:
                prioritized.append(candidate)
            elif "sop" in normalized_haystack or "procedure" in normalized_haystack:
                prioritized.append(candidate)
            else:
                fallback.append(candidate)

    if prioritized:
        return prioritized[0]
    if fallback:
        return fallback[0]
    return "", "", ""


def _has_direct_stop_requirement(excerpt: str) -> bool:
    normalized_excerpt = _normalize_text(excerpt)
    stop_markers = (
        "stop the line",
        "must stop",
        "halt production",
        "production must be stopped",
        "hold the batch",
        "batch must be held",
        "reject the batch",
    )
    return any(marker in normalized_excerpt for marker in stop_markers)


def _format_evidence_label(source: str, section: str) -> str:
    if source and section:
        return f"{source} {section}"
    return source or section


def _mentions_change_or_reason(normalized_text: str) -> bool:
    markers = (
        "reviewed",
        "checked",
        "question",
        "changed",
        "change",
        "same",
        "remains",
        "because",
        "evidence",
        "updated",
        "no change",
    )
    return any(marker in normalized_text for marker in markers)


def _normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip().lower()


def _shorten_text(text: str, limit: int) -> str:
    compact = re.sub(r"\s+", " ", text).strip()
    if len(compact) <= limit:
        return compact
    shortened = compact[: limit - 3].rsplit(" ", 1)[0].strip()
    return f"{shortened}..." if shortened else compact[: limit - 3] + "..."


def _compose_dialogue_parts(parts: list[str], limit: int = 800) -> str:
    message = ""
    for part in parts:
        compact_part = re.sub(r"\s+", " ", str(part or "")).strip()
        if not compact_part:
            continue

        candidate = f"{message} {compact_part}".strip() if message else compact_part
        if len(candidate) <= limit:
            message = candidate
            continue

        remaining = limit - len(message) - (1 if message else 0)
        if remaining <= 0:
            break

        shortened_part = _shorten_text(compact_part, remaining)
        message = f"{message} {shortened_part}".strip() if message else shortened_part
        break

    return message


def _human_join(items: list[str]) -> str:
    if not items:
        return "the analysis"
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"{items[0]} and {items[1]}"
    return ", ".join(items[:-1]) + f", and {items[-1]}"


def _normalize_incident_title(result: dict) -> str:
    explicit_title = str(result.get("title") or "").strip()
    if explicit_title:
        return explicit_title

    classification = str(result.get("classification") or result.get("deviation_classification") or "").strip()
    recommendation = str(result.get("recommendation") or result.get("analysis") or "").strip()

    if classification:
        return classification.replace("_", " ").title()

    if recommendation:
        short = recommendation.split(".", 1)[0].strip()
        return short[:80] if short else "Deviation Review Required"

    return "Deviation Review Required"


def _normalize_evidence_citations(result: dict, rag_context: dict) -> list[dict]:
    flat_hits = _flatten_rag_hits(rag_context)
    raw_items: list[dict] = []

    for item in result.get("evidence_citations", []) or []:
        if isinstance(item, dict):
            raw_items.append(item)
        elif isinstance(item, str):
            raw_items.append({"source": item})

    for item in result.get("sop_refs", []) or []:
        if isinstance(item, dict):
            raw_items.append({"type": "sop", **item})
        elif isinstance(item, str):
            raw_items.append({"type": "sop", "source": item, "document_id": item})

    for item in result.get("regulatory_refs", []) or []:
        if isinstance(item, dict):
            raw_items.append({"type": "gmp", **item})
        elif isinstance(item, str):
            raw_items.append({"type": "gmp", "source": item, "document_title": item})

    normalized: list[dict] = []
    seen: set[tuple] = set()
    for item in raw_items:
        citation = _normalize_single_citation(item, flat_hits)
        key = _citation_identity_key(citation)
        if key in seen:
            continue
        seen.add(key)
        normalized.append(citation)

    return normalized


def _flatten_rag_hits(rag_context: dict) -> list[dict]:
    hits: list[dict] = []
    for index_name, index_hits in rag_context.items():
        meta = INDEX_EVIDENCE_META.get(index_name, {})
        for hit in index_hits or []:
            hits.append(
                {
                    **hit,
                    "index_name": index_name,
                    "type": meta.get("type", hit.get("document_type", "")),
                    "container": meta.get("container", ""),
                }
            )
    return hits


def _normalize_single_citation(item: dict, flat_hits: list[dict]) -> dict:
    match = _find_matching_hit(item, flat_hits)
    citation_type = item.get("type") or _infer_citation_type(item, match)
    source = item.get("source") or (match or {}).get("document_id") or (match or {}).get("document_title") or ""
    reference = item.get("reference") or item.get("regulation") or ""
    document_title = (
        item.get("document_title")
        or item.get("title")
        or item.get("regulation")
        or item.get("reference")
        or (match or {}).get("document_title")
        or item.get("source")
        or ""
    )
    document_id = (
        item.get("document_id")
        or item.get("id")
        or item.get("reference")
        or (match or {}).get("document_id")
        or ""
    )
    source_blob = item.get("source_blob") or item.get("sourceBlob") or (match or {}).get("source", "")
    container = item.get("container") or (match or {}).get("container", "")
    if citation_type == "historical" and not document_id:
        document_id = _extract_historical_incident_id(source_blob or source or document_title)
    known_doc = _infer_known_document(item)
    if not document_id and known_doc:
        document_id = known_doc.get("document_id", "")
    if not source_blob and known_doc:
        source_blob = known_doc["source_blob"]
    if not container and known_doc:
        container = known_doc["container"]
    if known_doc and document_id == known_doc.get("document_id") and document_title != known_doc["document_title"]:
        document_title = known_doc["document_title"]
    elif known_doc and (
        not document_title
        or document_title in {"equipment_manual_notes", "incident", "details", "sop", "gmp", "manual", "batch record", "bpr_constraints"}
        or document_title.lower() in {
            known_doc.get("document_id", "").lower(),
            str(source or "").lower(),
            str(reference or "").lower(),
        }
    ):
        document_title = known_doc["document_title"]
    if citation_type == "historical" and document_id and document_title.lower() in {"incident", "details", "historical"}:
        document_title = f"Similar incident {document_id}"
    if not document_title:
        if citation_type == "historical" and document_id:
            document_title = f"Similar incident {document_id}"
        else:
            document_title = source or reference
    section = item.get("section") or item.get("relevant_section") or ""
    if citation_type == "historical" and not section:
        section = "Incident summary"
    text_excerpt = _build_citation_excerpt(item, match)
    url = item.get("url") or _citation_url(
        citation_type=citation_type,
        document_id=document_id,
        container=container,
        source_blob=source_blob,
    )
    resolution_status, unresolved_reason = _classify_citation_resolution(
        citation_type=citation_type,
        document_title=document_title,
        section=section,
        text_excerpt=text_excerpt,
        url=url,
        container=container,
        source_blob=source_blob,
    )

    citation = {
        "type": citation_type,
        "source": source,
        "reference": reference,
        "document_id": document_id,
        "document_title": document_title,
        "section": section,
        "text_excerpt": text_excerpt,
        "source_blob": source_blob,
        "container": container,
        "index_name": item.get("index_name") or (match or {}).get("index_name", ""),
        "chunk_index": item.get("chunk_index", (match or {}).get("chunk_index")),
        "score": item.get("score", (match or {}).get("score")),
        "resolution_status": resolution_status,
        "unresolved_reason": unresolved_reason,
    }
    citation["url"] = url
    return citation


def _citation_identity_key(citation: dict) -> tuple[str, str, str, str]:
    primary_id = (
        str(citation.get("source_blob") or "").strip()
        or str(citation.get("document_id") or "").strip()
        or str(citation.get("url") or "").strip()
        or str(citation.get("reference") or "").strip()
        or str(citation.get("source") or "").strip()
        or str(citation.get("document_title") or "").strip()
    )
    section = str(citation.get("section") or "").strip()
    status = str(citation.get("resolution_status") or "").strip()
    citation_type = str(citation.get("type") or "").strip()
    return (citation_type, primary_id.lower(), section.lower(), status)


def _build_citation_excerpt(item: dict, match: dict | None) -> str:
    raw_excerpt = _clean_excerpt_text(
        item.get("text_excerpt") or item.get("quote") or item.get("relevance") or ""
    )
    match_text = _clean_excerpt_text((match or {}).get("text", ""))

    if raw_excerpt and len(raw_excerpt) >= 120:
        return _trim_excerpt(raw_excerpt)

    if match_text:
        if raw_excerpt and len(raw_excerpt) >= 12:
            anchor_idx = match_text.lower().find(raw_excerpt.lower())
            if anchor_idx >= 0:
                return _excerpt_window(match_text, anchor_idx, len(raw_excerpt))
        return _trim_excerpt(match_text)

    if raw_excerpt:
        return _trim_excerpt(raw_excerpt)

    return ""


def _clean_excerpt_text(value: object) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    return text


def _trim_excerpt(text: str, max_chars: int = 300, min_break: int = 180) -> str:
    clean = _clean_excerpt_text(text)
    if len(clean) <= max_chars:
        return clean

    cut = clean[: max_chars + 1]
    for marker in (". ", "; ", ": ", ", ", " "):
        boundary = cut.rfind(marker)
        if boundary >= min_break:
            snippet = cut[: boundary + (1 if marker == " " else len(marker) - 1)].rstrip(" ,;:")
            return f"{snippet}..."

    return f"{clean[:max_chars].rstrip()}..."


def _excerpt_window(text: str, anchor_idx: int, anchor_len: int, radius: int = 120) -> str:
    start = max(0, anchor_idx - radius)
    end = min(len(text), anchor_idx + anchor_len + radius)
    snippet = text[start:end].strip()
    if start > 0:
        snippet = f"...{snippet}"
    if end < len(text):
        snippet = f"{snippet}..."
    return _trim_excerpt(snippet)


def _classify_citation_resolution(
    *,
    citation_type: str,
    document_title: str,
    section: str,
    text_excerpt: str,
    url: str,
    container: str,
    source_blob: str,
) -> tuple[str, str]:
    missing: list[str] = []

    if not document_title:
        missing.append("document title")
    if not section:
        missing.append("section")
    if not text_excerpt:
        missing.append("excerpt")
    if not url and not (container and source_blob):
        missing.append("link")

    if not missing:
        return "resolved", ""

    reason = f"Missing {', '.join(missing)} for {citation_type or 'evidence'} citation"
    return "unresolved", reason


def _citation_url(*, citation_type: str, document_id: str, container: str, source_blob: str) -> str:
    if citation_type == "historical":
        incident_id = _extract_historical_incident_id(document_id or source_blob)
        if incident_id:
            return f"/incidents/{quote(incident_id, safe='')}"
        return ""
    return _document_url(container, source_blob)


def _extract_historical_incident_id(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    stem = Path(text).stem
    match = re.search(r"(INC-\d{4}-\d{4,})", stem, re.IGNORECASE)
    return match.group(1).upper() if match else ""


def _find_matching_hit(item: dict, flat_hits: list[dict]) -> dict | None:
    candidates = [
        item.get("document_id"),
        item.get("id"),
        item.get("document_title"),
        item.get("title"),
        item.get("regulation"),
        item.get("reference"),
        item.get("source"),
        item.get("source_blob"),
    ]
    candidate_text = " ".join(str(c) for c in candidates if c).lower()
    excerpt = str(item.get("text_excerpt") or item.get("quote") or "").lower()

    for hit in flat_hits:
        hit_identifiers = " ".join(
            str(hit.get(k, ""))
            for k in ("document_id", "document_title", "source", "document_type")
        ).lower()
        if candidate_text and (
            candidate_text in hit_identifiers or hit_identifiers in candidate_text
        ):
            return hit
        if excerpt and (excerpt[:80] in str(hit.get("text", "")).lower()):
            return hit
    return None


def _infer_citation_type(item: dict, match: dict | None) -> str:
    text = " ".join(
        str(item.get(k, ""))
        for k in ("source", "reference", "document_title", "title", "regulation")
    ).lower()
    if match and match.get("type"):
        return match["type"]
    if "sop" in text:
        return "sop"
    if "gmp" in text or "annex" in text or "21 cfr" in text:
        return "gmp"
    if "manual" in text or "equipment" in text:
        return "manual"
    if "bpr" in text or "batch" in text:
        return "bpr"
    if "incident" in text or text.startswith("inc-"):
        return "historical"
    return "incident"


def _document_url(container: str, source_blob: str) -> str:
    if not container or not source_blob:
        return ""
    return f"/api/documents/{container}/{quote(source_blob, safe='/')}"


def _infer_known_document(item: dict) -> dict | None:
    text = " ".join(
        str(item.get(k, ""))
        for k in ("document_id", "document_title", "reference", "source", "text_excerpt", "id", "title", "regulation")
    ).lower()
    if "sop-dev-001" in text:
        return {
            "document_id": "SOP-DEV-001",
            "container": "blob-sop",
            "source_blob": "SOP-DEV-001-Deviation-Management.md",
            "document_title": "Deviation Management (SOP-DEV-001)",
        }
    if "sop-man-gr-001" in text or "granulator operation" in text:
        return {
            "document_id": "SOP-MAN-GR-001",
            "container": "blob-sop",
            "source_blob": "SOP-MAN-GR-001-Granulator-Operation.md",
            "document_title": "Granulator Operation (SOP-MAN-GR-001)",
        }
    if "annex 15" in text or "eu gmp" in text:
        return {
            "document_id": "GMP-Annex15-Excerpt",
            "container": "blob-gmp",
            "source_blob": "GMP-Annex15-Excerpt.md",
            "document_title": "EU GMP Annex 15",
        }
    if "metformin" in text or "b26041701" in text:
        return {
            "document_id": "BPR-MET-500-v3.2",
            "container": "blob-bpr",
            "source_blob": "BPR-MET-500-v3.2-Process-Specification.md",
            "document_title": "BPR Metformin 500mg Process Specification",
        }
    return None


def _write_analysis_started_event(incident_id: str) -> None:
    """Write an analysis_started audit event when the AI agent begins processing."""
    from azure.cosmos.exceptions import CosmosResourceExistsError
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    event = {
        "id": f"{incident_id}-analysis-started-{int(datetime.now(timezone.utc).timestamp())}",
        "incident_id": incident_id,
        "incidentId": incident_id,
        "timestamp": now,
        "action": "analysis_started",
        "actor": "AI Orchestrator",
        "actor_type": "agent",
        "category": "status",
        "details": "AI agent started analyzing the incident — researching SOPs, equipment history and GMP guidelines.",
    }
    try:
        container = get_container("incident_events")
        container.create_item(event, enable_automatic_id_generation=False)
    except CosmosResourceExistsError:
        pass  # idempotent on orchestrator replay
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not write analysis_started event for %s: %s", incident_id, exc)
